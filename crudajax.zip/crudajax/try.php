<!DOCTYPE html>
<html>
   <head>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script>
         $(document).ready(function() {
           $('.error').hide();
           $('#submit').click(function(){
                var name = $('#name').val();
                var email = $('#email').val();
                
                if(name== ''){
                   $('#name').next().show();
                   return false;
                 }
                 if(email== ''){
                    $('#email').next().show();
                    return false;
                 }
                 if(IsEmail(email)==false){
                     $('#invalid_email').show();
                     return false;
                 }
                 $.post("", $("#myform").serialize(),  function(response) {
                 $('#myform').fadeOut('slow',function(){
                     $('#correct').html(response);
                     $('#correct').fadeIn('slow');
                    });
                  });
                  return false;
               });
           });
           function IsEmail(email) {
             var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
             if(!regex.test(email)) {
                return false;
             }else{
                return true;
             }
           }
      </script>
   </head>
   <body>
      <form action="" method="post" id="contactform">
         <table class="mytable">
            <tr>
               <td><label for="name">Name :</label></td>
               <td class="name"> <input name="name" id="name" type="text" placeholder="Please enter your name" class="contact-input"><span class="error">Enter your name here</span></td>
            </tr>
            <tr>
               <td><label for="email">Email :</label></td>
               <td class="email"><input name="email" id="email" type="text" placeholder="Please enter your email" class="contact-input"><span class="error">Enter your email-id here</span>
                  <span class="error" id="invalid_email">Email-id is invalid</span>
               </td>
            </tr>
            <tr>
               <input type="submit" class="contactform-buttons" id="submit"value="Send" />
               <input type="reset" class="contactform-buttons" id="" value="Clear" />
               </td>
            </tr>
         </table>
      </form>
      <div id="correct" style="color:gray;"></div>
   </body>
   <script>
       if(fname=='')
        {
          $('#fname-error-msg').html('First Name Required');
          return false;
        }
        if(lname=='')
        {
            $('#lname-error-msg').html('Last Name Required');
            return false;
        }
        if(email=='')
        {
            $('#email-error-msg').html('Email Required');
            return false;
        } 
        function IsEmail(email) {
             var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
             if(!regex.test(email)) {
                return false;
             }else{
                return true;
             }
           }
           if(IsEmail(email)==false){
                     $('#email-valid').html('Please Enter Valid Email id');
                     return false;
                 }
        if(phone=='')
        {
            $('#phone-error-msg').html('Phone Number Required');
            return false;
        }
        if(address=='')
        {
            $('#address-error-msg').html('Address Required');
            return false;
        }
       $.ajax({
         url:'input.php',
         type:'POST',
         data:$('student-from').serialize(),
         success:function(result)
         {
             alert(result);
         }


       });
         e.preventDefault();
    });
   
    });
       </script>
</html>