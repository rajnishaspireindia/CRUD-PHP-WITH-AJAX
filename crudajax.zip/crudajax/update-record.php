<?php 
include('config.php');
$sid=$_POST['student-id'];
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
$sql=mysqli_query($conn,"UPDATE students SET fname='{$fname}',lname='{$lname}',email='{$email}',phone='{$phone}',`address`='{$address}' WHERE id={$sid}");
if($sql)
{
    echo "Record Updated Successfully";
}
else
{
    echo "Something Went wrong";
}

?>