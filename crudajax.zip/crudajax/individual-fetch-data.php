<?php 
include('config.php');
$id=$_POST['id'];

$sql=mysqli_query($conn,"SELECT * FROM students WHERE id={$id}");

while($row=mysqli_fetch_assoc($sql))
{
    echo "<form id='update-student-form' method='POST'>
    <div class='row'>
    <div class='col-lg-6 pb-3'>
    <label for='fname'>First Name</label>
    <input type='text' class='form-control' name='fname' id='fname' value='{$row['fname']}'>
    <input type='text' class='form-control' name='student-id' hidden id='fid' value='{$row['id']}'>
    <div id='fname-error-msg' class='error-msg'></div>
    </div>
    <div class='col-lg-6 pb-3'>
    <label for='fname'>Last Name</label>
    <input type='text' class='form-control' name='lname' id='lname' value='{$row['lname']}'>
    <div id='lname-error-msg' class='error-msg'></div>
    </div>
    </div>
    <div class='row'>
    <div class='col-lg-6 pb-3'>
        <label for='email'>Email</label>
        <input type='text' class='form-control' name='email' id='email' value='{$row['email']}'>
        <div id='email-error-msg' class='error-msg'></div>
        <div id='email-valid' class='error-msg'></div>
    </div>
    <div class='col-lg-6 pb-3'>
        <label for='phone'>Phone</label>
        <input type='text' class='form-control' name='phone'  id='phone' value='{$row['phone']}'>
        <div id='phone-error-msg' class='error-msg'></div>
        <div id='phone-valid' class='error-msg'></div>
    </div>
   </div>
   <div class='row'>
    <div class='col-lg-12 pb-3'>
        <label for='address'>Address</label>
        <textarea class='form-control' name='address' id='address'>{$row['address']}</textarea>
        <div id='address-error-msg' class='error-msg'></div>
    </div>
    </div>
    <div class='col-lg-12'>
        <center><input type='submit' class='btn btn-primary' value='Update' id='update-btn'></center>
    </form>";
}










?>