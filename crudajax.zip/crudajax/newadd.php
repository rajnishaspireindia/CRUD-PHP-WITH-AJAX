<html>
<head>
<title>CRUD-AJAX</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <center><h1 class="pt-4">Student Registration Form</h1></center>
    <div id="error-msg" class="error-msg"></div>
    <div id="success-msg" class="success-msg"></div>
       <form id="student-form" method="POST">
        <div class="row">
        <div class="col-lg-6 pb-3">
        <label for="fname">First Name</label>
        <input type="text" class="form-control" name="fname" id="fname" placeholder="Enter First Name" required>
        <div id="fname-error-msg" class="error-msg"></div>
        </div>
        <div class="col-lg-6 pb-3">
        <label for="fname">Last Name</label>
        <input type="text" class="form-control" name="lname" id="lname" placeholder="Enter Last Name">
        <div id="lname-error-msg" class="error-msg"></div>
        </div>
        </div>
        <div class="row">
        <div class="col-lg-6 pb-3">
            <label for="email">Email</label>
            <input type="email" class="form-control" name="email" id="email" placeholder="Enter Email Id" required>
            <div id="email-error-msg" class="error-msg"></div>
            <div id="email-valid" class="error-msg"></div>
        </div>
        <div class="col-lg-6 pb-3">
            <label for="phone">Phone</label>
            <input type="number" class="form-control" name="phone"  id="phone" placeholder="Enter Phone Number" required>
            <div id="phone-error-msg" class="error-msg"></div>
            <div id="phone-valid" class="error-msg"></div>
        </div>
       </div>
       <div class="row">
        <div class="col-lg-12 pb-3">
            <label for="address">Address</label>
            <textarea class="form-control" name="address" id="address" placeholder="Enter Address" required></textarea>
            <div id="address-error-msg" class="error-msg"></div>
        </div>
        </div>
        <div class="col-lg-12">
            <center><input type="submit" class="btn btn-primary" value="Save" id="sb-btn"></center>
        </form>
        
    
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
    $(document).ready(function(){
    $('#student-form').on('submit',function(e){
        var fname=$('#fname').val();
        var lname=$('#lname').val();
        var email=$('#email').val();
        var phone=$('#phone').val();
        var address=$('#address').val();
        if(fname=='' || lname=='' || email=='' || phone=='' || address=='')
        {
         $('#error-msg').html('All Fields are required');
        }
        else
        {
         $('#sb-btn').val('Please Wait..');   
         $('#sb-btn').attr('disabled',true);
        $.ajax({
            url:'input.php',
            type:'POST',
            data:$('#student-form').serialize(),
            success:function(result)
            {
            $('#student-form').trigger('reset');
            $('#success-msg').html(result);
           function pageRedirect() {
        window.location.replace("index.php");
            }      
           pageRedirect() ;
           alert('New Recored Added');
            $('#sb-btn').val('Save');
            $('#sb-btn').attr('disabled',false);
            }
        }) ;
         
        }

    e.preventDefault();    
    });
});  
</script>
</body>
    </html>


