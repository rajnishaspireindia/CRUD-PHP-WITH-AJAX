<?php 
include('config.php');
$sql=mysqli_query($conn,"SELECT * FROM students");

$k=1;
while($row=mysqli_fetch_assoc($sql))
{
    echo '<tr>
          <td scope="row">'.$k.'</td>
          <td>'.$row['fname'].'</td>
          <td>'.$row['lname'].'</td>
          <td>'.$row['email'].'</td>
          <td>'.$row['phone'].'</td>
          <td>'.$row['address'].'</td>
          <td><button type="button" class="edit-btn" data-eid='.$row['id'].'>Edit</button> &nbsp;&nbsp; <button type="button" class="delete-btn" id="delete-btn" data-id='.$row['id'].'>Delete</button> </td>
         </tr>';
         $k++;
}



?>