
<html>
<head>
<title>CRUD-AJAX</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
    <center><h1 class="pt-4">All Student List</h1></center>
    <a href="newadd.php" style='text-align:right;'>Add New Record</a>
    <div class="row">
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email Id</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="all-data">
            </tbody>
        </table>
        <div id="modal">
            <div id="modal-form">
            <div id="feth-form">
           </div>
           <div id="close-btn">X</div>
        </div>
        
</div>
    </div>
</div>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     <script>
     $(document).ready(function(){
        //script for fetch-data
     function load_data()
     {
       $.ajax({
           url:'fetch-data.php',
           type:'POST',
           success:function(data)
           {
               if(data)
               {
                $('#all-data').html(data);
               }

               else
               {
                   $('#all-data').html('No Record');
               }
              
           }
       });  
     }
      load_data();
      //script for delete-record
     $(document).on("click",".delete-btn", function(){
        
         if(confirm('Do you really want to delete this record?'))
         {
            var studid=$(this).data('id');
         $.ajax({
          url:'delete-record.php',
          type:'POST',
          data:{id:studid},
          success:function(data)
          {
              alert(data);
              load_data();
          }

         });
         }
         
     });
     //script for fetch individual record
     $(document).on("click",".edit-btn",function(){
     $('#modal').show();
     var stueid=$(this).data('eid');
     $.ajax({
         url:'individual-fetch-data.php',
         type:'POST',
         data:{id:stueid},
         success:function(result)
         {
            $('#feth-form').html(result);
         } 
         


     });


     });
     $('#close-btn').on('click',function(){
     $('#modal').hide();
     });
     //script for update record
     $(document).on("click","#update-btn", function(){
        $.ajax({
            url:'update-record.php',
            type:'POST',
            data:$('#update-student-form').serialize(),
            success:function(result)
            {
                alert(result);
                load_data();
            }


        });

     });


     });
     
     </script>
</body>
    </html>


