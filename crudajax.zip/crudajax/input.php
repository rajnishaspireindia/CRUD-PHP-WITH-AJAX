<?php 
include ('config.php');
sleep(5);

if(isset($_POST['fname']))
{
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];

    $sql=mysqli_query($conn,"INSERT INTO students (fname,lname,email,phone,`address`) VALUES('$fname','$lname','$email','$phone','$address')");
    if($sql)
    {
        echo "New Record Added";
    }
    else
    {
        echo "Something Went Wrong";
    }

}






?>