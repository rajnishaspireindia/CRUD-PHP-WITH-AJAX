<?php 
include('config.php');
$id=$_POST['id'];
$sql=mysqli_query($conn,"DELETE FROM students WHERE id={$id}");

if($sql)
{
    echo "Record Deleted";
}
else{
    echo "something went wrong";
}



?>