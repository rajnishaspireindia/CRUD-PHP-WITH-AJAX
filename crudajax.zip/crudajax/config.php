<?php 

$conn=mysqli_connect('localhost','root','','ajax_crud') or die('Database Connection Faild');

?>